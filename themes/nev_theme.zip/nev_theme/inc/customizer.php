<?php
/**
 * Nev Theme Theme Customizer file
 *
 * @package Nev_Theme
 */

	/**
	 * Panel
	 */

	/**
	 * Sections
	 */

	/**
	 * Settings
	 */

	/**
	 * Controls
	 */

	// Using the set customizer control

	
